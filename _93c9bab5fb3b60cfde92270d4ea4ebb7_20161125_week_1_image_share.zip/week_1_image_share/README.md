
To run this app, you must first run the command:

meteor npm install



The packages.json is a new thing that allows you to use node packages directly. 
 
More info here:

https://guide.meteor.com/using-npm-packages.html
